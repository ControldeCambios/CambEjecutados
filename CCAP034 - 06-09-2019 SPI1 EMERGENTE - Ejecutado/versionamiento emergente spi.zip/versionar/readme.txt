VERSIONAR
1.- SUBIR FORMULARIO 04-5009
2.- SUBIR CLASSS SPI2TransferLoteAddItem EN EL JAR LOTE EN LA RUTA com.fitbank.lote.process
3.- SUBIR CLASSS MarkStatusSpiSci EN EL JAR VIEW EN LA RUTA com.fitbank.view.files
4.- SUBIR CLASSS AddHeadReportBCE EN EL JAR VIEW EN LA RUTA com.fitbank.view.report