/*
Produccion 
*/
/*
Importante
Resagado por diferencias en saldo moneda oficial 
cuenta 51042003
*/
UPDATE fitbank.tsaldos
SET saldomonedaoficial=286.84-91.81 
where ccuenta = '604090001357'
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and '24/04/2019' BETWEEN FDESDE AND FHASTA
AND SUBCUENTA IN (20);

update tsaldos 
set saldomonedacuenta=25+24.89, saldomonedaoficial=25+24.89
where ccuenta='604090000895' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (25)
and '17/05/2019' between fdesde and fhasta;

update tsaldos 
set saldomonedacuenta=38.04+24.89, saldomonedaoficial=38.04+24.89
where ccuenta='604090000895' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (25)
and '20/05/2019' between fdesde and fhasta;

update tsaldos 
set saldomonedacuenta=136.39, saldomonedaoficial=136.39
where ccuenta='604090005447' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (4)
and '20/05/2019' between fdesde and fhasta;
/*
fin de resagado
*/

--ACTUALIZACIONES NUEVA CUENTA 51041003

--Oficina 6
update tsaldos
set saldomonedacuenta=139.26-69.63, saldomonedaoficial=139.26-69.63
where ccuenta='602020005608' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (21,22)
and '01/02/2019' between fdesde and fhasta
and subcuenta=21;

update tsaldos
set saldomonedacuenta=116.99-(68.82-19.98), saldomonedaoficial=116.99-(68.82-19.98)
where ccuenta='602020005608' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (21,22)
and '01/02/2019' between fdesde and fhasta
and subcuenta=22;

update tsaldos
set saldomonedacuenta=0, saldomonedaoficial=0, montodescargaprovision=0,  montodescargaprovisionoficial=0
where ccuenta='602020005608' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (22)
and '14/02/2019' between fdesde and fhasta
and fhasta='14/02/2019';


update tsaldos
set saldomonedacuenta=48.17+(116.99-48.84), saldomonedaoficial=48.17+(116.99-48.84), montodescargaprovision=68.82,  montodescargaprovisionoficial=68.82
where ccuenta='602020005608' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (22)
and '14/02/2019' between fdesde and fhasta
and fhasta<>'14/02/2019';

update tsaldos
set saldomonedacuenta=(116.99-0.67), saldomonedaoficial=(116.99-0.67)
where ccuenta='602020005608' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (22)
and '28/02/2019' between fdesde and fhasta;

update tsaldos
set saldomonedacuenta=(27.70+23.45), saldomonedaoficial=(27.70+23.45),montodescargaprovision=51.93,  montodescargaprovisionoficial=51.93
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (24)
and '19/02/2019' between fdesde and fhasta;
--order by subcuenta;

update tsaldos
set saldomonedacuenta=(51.93-0.78), saldomonedaoficial=(51.93-0.78),montodescargaprovision=27.7,  montodescargaprovisionoficial=27.7
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (24)
and '20/02/2019' between fdesde and fhasta;


update tsaldos
set fhasta='07/04/2019', particion='201904', fcontablehasta='07/04/2019'
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (25)
and '22/03/2019' between fdesde and fhasta;

update tsaldos
set saldomonedacuenta=49.54, saldomonedaoficial=49.54
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (25)
and '08/04/2019' between fdesde and fhasta;

update tsaldos
set fhasta='25/04/2019', fcontablehasta='25/04/2019'
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (26)
and '19/04/2019' between fdesde and fhasta;

update tsaldos
set saldomonedacuenta=42.56, saldomonedaoficial=42.56
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (26)
and '26/04/2019' between fdesde and fhasta;


--Oficina 11

update tsaldos
set saldomonedacuenta=54.69-(32.17-9.34), saldomonedaoficial=54.69-(32.17-9.34)
where ccuenta='602020003144' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (27)
and '19/01/2019' between fdesde and fhasta;

update tsaldos
set saldomonedacuenta=73.14-(42.20-5.45), saldomonedaoficial=73.14-(42.20-5.45)
where ccuenta='602020012787' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (11)
and '09/02/2019' between fdesde and fhasta;

update tsaldos
set saldomonedacuenta=54.69-(32.17-9.34), saldomonedaoficial=54.69-(32.17-9.34)
where ccuenta='602020003144' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (27)
and '13/02/2019' between fdesde and fhasta;

update tsaldos
set saldomonedacuenta=82.72-(42.81), saldomonedaoficial=82.72-(42.81)
where ccuenta='602020012787' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (10)
and '11/03/2019' between fdesde and fhasta;

--Oficina 32
update tsaldos
set saldomonedacuenta=56.28-28.14, saldomonedaoficial=56.28-28.14
where ccuenta='602020012895' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (10)
and '11/01/2019' between fdesde and fhasta;
--order by subcuenta;

update tsaldos
set saldomonedacuenta=(54.48-26.78)-0.03, saldomonedaoficial=(54.48-26.78)-0.03
where ccuenta='602020012895' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (11)
and '11/01/2019' between fdesde and fhasta;


--Oficina 33
update tsaldos
set saldomonedacuenta=50.76-25.38, saldomonedaoficial=50.76-25.38
where ccuenta='602020007360' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (19)
and '11/01/2019' between fdesde and fhasta;

update tsaldos
--set saldomonedacuenta=21.61, saldomonedaoficial=21.61, montodescargaprovision=24.93  , montodescargaprovisionoficial=24.93 
set saldomonedacuenta=(46.54-21.61)-0.1, saldomonedaoficial=(46.54-21.61)-0.1
where ccuenta='602020007360' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (20)
and '11/01/2019' between fdesde and fhasta;


update tsaldos
set saldomonedacuenta=0, saldomonedaoficial=0, montodescargaprovision=0, montodescargaprovisionoficial=0 
where ccuenta='602020007360' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (20)
and '09/02/2019' between fdesde and fhasta
AND FHASTA='09/02/2019';

update tsaldos
set saldomonedacuenta=(21.61+(46.54-21.61)-0.1), saldomonedaoficial=(21.61+(46.54-21.61)-0.1), montodescargaprovision=24.93, montodescargaprovisionoficial=24.93 
where ccuenta='602020007360' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (20)
and '09/02/2019' between fdesde and fhasta
AND FHASTA<>'09/02/2019';


update tsaldos
set saldomonedacuenta=46.54-0.1, saldomonedaoficial=46.54-0.1
where ccuenta='602020007360' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (20)
and '16/02/2019' between fdesde and fhasta;

update tsaldos
set saldomonedacuenta=(50.05-23.24)-0.11, saldomonedaoficial=(50.05-23.24)-0.11
where ccuenta='602020009682' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (16)
and '12/02/2019' between fdesde and fhasta;


--Oficina 9

update tsaldos
set saldomonedacuenta=0, saldomonedaoficial=0, montodescargaprovision=0, montodescargaprovisionoficial=0 
where ccuenta='602020008369' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (18)
and '22/02/2019' between fdesde and fhasta
and fhasta='22/02/2019';

update tsaldos
set saldomonedacuenta=77.77+23.51, saldomonedaoficial=77.77+23.51, montodescargaprovision=54.26, montodescargaprovisionoficial=54.26 
where ccuenta='602020008369' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (18)
and '22/02/2019' between fdesde and fhasta
and fhasta<>'22/02/2019';

update tsaldos
set saldomonedacuenta=53.41+23.51, saldomonedaoficial=53.41+23.51
where ccuenta='602020008369' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (18)
and '03/04/2019' between fdesde and fhasta;

update tsaldos
set saldomonedacuenta=64.81+23.51, saldomonedaoficial=64.81+23.51
where ccuenta='602020008369' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (18)
and '09/04/2019' between fdesde and fhasta;