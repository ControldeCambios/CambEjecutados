--**************************
--mayoriza de un d�a
--**************************
DECLARE
    VFECHA DATE:=TO_DATE('2019/05/18','YYYY/MM/DD');
BEGIN
     MAYORIZACION(VFECHA);
EXCEPTION
WHEN OTHERS THEN
DBMS_OUTPUT.PUT_LINE('ERROR: '||SQLERRM);
END;