/*
Respaldos
*/
--Oficina 6
insert into tmp_51041003
select *
from tsaldos
where ccuenta='602020005608' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (21,22)
and '01/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020005608' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (22)
and '14/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020005608' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (22)
and '28/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (24)
and '19/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (24)
and '20/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (25)
and '22/03/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (25)
and '08/04/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (26)
and '19/04/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020004853' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (26)
and '26/04/2019' between fdesde and fhasta
order by subcuenta;

--Oficina 11

insert into tmp_51041003
select *
from tsaldos
where ccuenta='602020003144' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (27)
and '19/01/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020012787' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (11)
and '09/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020003144' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (27)
and '13/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020012787' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (10)
and '11/03/2019' between fdesde and fhasta
order by subcuenta;

--Oficina 32
insert into tmp_51041003
select *
from tsaldos
where ccuenta='602020012895' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (10,11)
and '11/01/2019' between fdesde and fhasta
order by subcuenta;

--Oficina 33
insert into tmp_51041003
select *
from tsaldos
where ccuenta='602020007360' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (19,20)
and '11/01/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020007360' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (20)
and '09/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020007360' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (20)
and '16/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020009682' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (16)
and '12/02/2019' between fdesde and fhasta
order by subcuenta;

--Oficina 9
insert into tmp_51041003
select *
from tsaldos
where ccuenta='602020008369' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (18)
and '22/02/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020008369' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (18)
and '03/04/2019' between fdesde and fhasta
union
select *
from tsaldos
where ccuenta='602020008369' 
and cgrupobalance=05
and ctiposaldocategoria='ACC'
and categoria='INTPRO'
and subcuenta in (18)
and '09/04/2019' between fdesde and fhasta
order by subcuenta;