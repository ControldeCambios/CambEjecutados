insert into CANAL29.tsistransacciones values('04', '0030', 'CARGA DE ARCHIVO SPI 4', 1, 0);
insert into CANAL29.tsismenutransacciones values('EST', '04', '0030');
INSERT INTO CANAL29.TSISTRANSACCIONROL (CMODULO, CTRANSACCION, CROL, HORADESDE, HORAHASTA) VALUES
('04', '0030', '000', '0000', '2359');